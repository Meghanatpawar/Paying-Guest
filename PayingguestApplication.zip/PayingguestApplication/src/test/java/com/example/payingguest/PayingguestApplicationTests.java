package com.example.payingguest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PayingguestApplicationTests {

	@Test
	void contextLoads() {
	}

}
