package com.example.payingguest.exception;

public class CustomException extends RuntimeException {
	/**
	 * 
	 */
	private static final long serialVersionUID = -9010847991894817191L;

	public CustomException(String msg) {
		super(msg);

	}
}
