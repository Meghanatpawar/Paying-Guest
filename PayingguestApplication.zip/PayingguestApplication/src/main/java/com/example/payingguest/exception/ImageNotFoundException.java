package com.example.payingguest.exception;

public class ImageNotFoundException extends RuntimeException {
/**
	 * 
	 */
	private static final long serialVersionUID = 7274884496810425216L;

public ImageNotFoundException(String msg) {
	    super(msg);
}
}
