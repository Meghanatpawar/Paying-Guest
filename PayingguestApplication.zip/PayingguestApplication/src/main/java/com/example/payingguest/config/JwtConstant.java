package com.example.payingguest.config;

public class JwtConstant {
	public static final String SECRET_KEY = "hjgdjytdxuytkuytfuytsreqasutrifxsxglyliugkyf";
	public static final String JWT_HEADER = "Authorization";
}
