package com.example.payingguest.exception;

public class RoomNotFoundExceptions extends RuntimeException {
	/**
	 * 
	 */
	private static final long serialVersionUID = -3042240097890170734L;

	public RoomNotFoundExceptions(String msg) {
		super(msg);
	}
}
